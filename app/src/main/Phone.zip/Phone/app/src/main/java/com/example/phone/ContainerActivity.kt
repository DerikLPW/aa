package com.example.phone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.kotlin.fragment.FirstFragment
import com.example.kotlin.fragment.SecondFragment
import com.example.kotlin.fragment.ThirdFragment

class ContainerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_container)

        replaceFragment(FirstFragment.newInstance(), "FirstFragment", false)
    }


    fun replaceFragment(fragment: Fragment, tag: String, addToBackStack: Boolean) {
        val beginTransaction = supportFragmentManager.beginTransaction()
        beginTransaction.replace(R.id.fl_container, fragment, tag)
        if (addToBackStack) {
            beginTransaction.addToBackStack(tag)
        }
        beginTransaction.commitAllowingStateLoss()
    }

//    fun startFirstFragment() {
//        replaceFragment(FirstFragment.newInstance(), "FirstFragment", false)
//    }

//    fun startSecondFragment() {
//        replaceFragment(SecondFragment.newInstance(), "SecondFragment", true)
//    }

//    fun startThirdFragment() {
//        replaceFragment(ThirdFragment.newInstance(), "ThirdFragment", true)
//    }
}
