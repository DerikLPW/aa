package com.example.kotlin.fragment

data class FirstBean(
    val result: List<Result>
)

data class Result(
    val code: String,
    val detail: List<Detail>,
    val status: String,
    val title: String
)

data class Detail(
    val rate: String,
    val sub_title: String,
    val time: String,
    val value: String
)